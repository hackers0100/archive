Array.prototype.shuffle = function () {
    let a = this;
    for (let i = a.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [a[i], a[j]] = [a[j], a[i]];
    }
    return a;
}

async function load() {
    var n = 0;
    let CadetList = await fetch(`/api/cadets/list`);
    CadetList = await CadetList.json()
    
    $('#loading').css("display","none");

    let selection = CadetList.slice(n, n + 10);
    loadMore(selection);

    $(window).scroll(function () {
        if ($(window).scrollTop() + $(window).height() > $(document).height() - 200) {
            n += 10;
            loadMore(CadetList.slice(n, n + 10));
        }
    });
};

function loadMore(res) {
    res.forEach(function (cdt) {
        if (cdt.state == "unverified") {return};
        
        let html = `
        <div class="card" id="c-${cdt.sch_no}">
            <!-- img src="" "${cdt.logo}" class="icon" -->
            <h2 class="title">
                ${cdt.sch_no || "Admin"}
            </h2><br>`
        if (cdt.admin){
                html+=`<a class="badge">admin</a>`
        } else {
            html += `<a class="badge">Quiz Score: ${cdt.score}</a>`
        }
        html+=`
            <p class="desc">${cdt.description || ""}</p>
            <a class="button small edit" data-name="${cdt.sch_no}">Edit Info</a>
            <a class="button small delete" data-name="${cdt.sch_no}">Delete Info</a>
        </div>`

        document.getElementById('cards').insertAdjacentHTML("beforeend", html)
    })
}
function wait(seconds) {
    return new Promise((resolve, _) => {
        setTimeout(() => {
            resolve(true)
        }, 1000*seconds)
    })
}

$( document ).ready(async function() {
    $(document).on("click",".delete", async function () {
        let id = $(this).attr("data-name");
        let res;
        await Swal.fire({
            title: `Deleting Information of ${id}`,
            icon: 'warning',
            html: `Type <u>${id}</u> to confirm`,
            showCancelButton: true,
            input: "text",
            confirmButtonText: `Delete`,
            preConfirm: async (name) => {
                if (name.toLowerCase() !== id.toLowerCase()) {
                    Swal.update({
                        title: "Cancelled",
                        html: ""
                    });
                    await wait(1);
                } else {
                    res = await fetch(`/api/cadets/${id}`, {method: "DELETE"});
                    // check for status.
                    if (res.status != 200) {
                        Swal.update({
                            title: "Error Deleting the Cadet's Information",
                            html: `Server returned status code ${res.status}`,
                            icon: "error"
                        });
                        await wait(2);
                        return;
                    } else {
                        Swal.update({
                            title: "Successfully Deleted the Cadet's Information",
                            html: "",
                            icon: "success"
                        });
                        await wait(1);
                        $(`#c-${id}`).remove();
                    }
                }
            }
        })
    });

    $(document).on("click",".edit", async function () {
        let id = $(this).attr("data-name");
        let res;
        await Swal.fire({
            title: `Editing Password of ${id}`,
            icon: 'warning',
            // html: `Type <u>${id}</u> to confirm`,
            showCancelButton: true,
            input: "password",
            confirmButtonText: `Change`,
            preConfirm: async (name) => {
                if (!name) {
                    Swal.update({
                        title: "Cancelled"
                    });
                    return await wait(2);
                }
                res = await fetch(`/api/cadets/${id}`, {method: "PATCH", body: JSON.stringify({pwd: name})});
                // check for status.
                if (res.status != 200) {
                    Swal.update({
                        title: "Error Changing the Cadet's Password",
                        html: `Server returned status code ${res.status}`,
                        icon: "error"
                    });
                    await wait(2);
                    return;
                } else {
                    Swal.update({
                        title: "Successfully Changed the Cadet's Password",
                        html: "",
                        icon: "success"
                    });
                    await wait(1);
                    // $(`#c-${id}`).remove();
                }
            }
        })
    });
});
function search() {
    if (document.getElementById('search').contentEditable === "false") return;
    let s = String(document.getElementById('search').innerHTML.toLowerCase()).replaceAll('<br>', "");
    let cards = document.getElementById('cards');
    cards.style.display = "none";
    if (document.getElementById('loading')) document.getElementById('loading').display = "block";
    if (cards) {
        let cardsVisible = 0;

        let list = cards.children;
        for (var i = 1; i < list.length; i++) {
            let card = list[i];
            let title = card.children[1].innerHTML.toLowerCase();
            let desc = card.children[2].innerHTML.toLowerCase();
            if (!title.includes(s) && !desc.includes(s)) card.style.display = "none";
            else {
                card.style.display = "inline-block";
                cardsVisible++;
            }
        }

        if (cardsVisible === 0) {
            document.getElementById('searchMore').innerHTML = `No bots found. Would you like to <a href="/bots/search/?q=${s}">search all bots</a>?`;
            document.getElementById('searchMore').style.display = "block";
        } else {
            document.getElementById('searchMore').innerHTML = `Would you like to <a href="/bots/search/?q=${s}">search all bots</a>`
            document.getElementById('searchMore').style.display = "block";
        }

        if (document.getElementById('search').innerHTML === "") {
            document.getElementById('searchMore').style.display = "none";
            for (var i = 1; i < list.length; i++) {
                let card = list[i];
                card.style.display = "inline-block";
            }
        }
    }
    if (document.getElementById('loading')) document.getElementById('loading').display = "none";
    cards.style.display = "block";
}