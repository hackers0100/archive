function wait(seconds) {
    return new Promise((resolve, _) => {
        setTimeout(() => {
            resolve(true)
        }, 1000*seconds)
    })
}

$( document ).ready(async function() {
    $(document).on("click",".delete", async function () {
        let id = $(this).attr("data-id");
        let res;
        await Swal.fire({
            title: `Deleting Entry of ${$(this).attr("data-name")}`,
            icon: 'warning',
            html: `Type <u>${$(this).attr("data-name")}</u> to confirm`,
            showCancelButton: true,
            input: "text",
            confirmButtonText: `Delete`,
            preConfirm: async (name) => {
                if (name.toLowerCase() !== $(this).attr("data-name").toLowerCase()) {
                    Swal.update({
                        title: "Cancelled",
                        html: ""
                    });
                    await wait(1);
                } else {
                    res = await fetch(`/oba/${id}`, {method: "DELETE"});
                    // check for status.
                    if (res.status != 200) {
                        Swal.update({
                            title: "Error Deleting the OBA Entry",
                            html: `Server returned status code ${res.status}`,
                            icon: "error"
                        });
                        await wait(2);
                        return;
                    } else {
                        Swal.update({
                            title: "Successfully Deleted the OBA Entry",
                            html: "",
                            icon: "success"
                        });
                        await wait(1);
                        $(`#row-${id}`).remove();
                    }
                }
            }
        })
    });
    $(document).on("click",".view", async function () {
        let id = $(this).attr("data-id");
        let name = $(this).attr("data-name");
        await Swal.fire({
            title: `Message from ${name}`,
            text: $(`#msg-${id}`).text(),
        })
    })
})