from tortoise.models import Model
from tortoise import fields
from tortoise.fields import BigIntField, TextField, CharField
import random
from quart_auth import AuthUser


class User(Model, AuthUser):
    __tablename__ = "users"
    __table_args__ = {'extend_existing': True}
    
    id = BigIntField(pk=True)
    
    @property
    def _auth_id(self):
        return self.id
    
    username = CharField(unique=True, required=True, max_length=30)
    password = TextField()
    role = TextField(default="cadet")

class Cadet(Model):
    sch_no = BigIntField(pk=True)
    user = fields.ForeignKeyField("models.User", "model_")
    score = fields.SmallIntField(default=0)
    total = fields.SmallIntField(default=0)
    
    async def json(self):
        return dict(
            sch_no = self.sch_no,
            score = self.score,
            admin = (await self.user).role == 'admin'
        )

class Question(Model):
    id = BigIntField(pk=True)
    question_text = TextField(null = False)
    option1 = TextField()
    option2 = TextField()
    option3 = TextField()
    option4 = TextField()
    category = CharField(max_length=50, null=False, default="GK")
    explanation = TextField(null=True)
    correct_option = fields.SmallIntField()  # 1 to 4

    @classmethod
    async def get_random_questions(cls, num_questions: int, category: str = "GK"):
        l = await cls.filter(category=category)
        random.shuffle(l)
        return l[:num_questions]

class QuizResult(Model):
    id = BigIntField(pk=True)
    cadet = fields.ForeignKeyField("models.Cadet", "quizresults")
    score = fields.SmallIntField()
    total_questions = fields.SmallIntField()
    date_taken = fields.DatetimeField(auto_now_add=True)


class OBARegistration(Model):
    name = TextField()
    sch_no = BigIntField()
    year_of_passing = fields.SmallIntField()
    occupation = TextField()
    email = TextField()
    phone = TextField()
    address = TextField()
    food_preference = TextField()
    date_of_arrival = fields.DatetimeField()
    message = TextField(null=True)
    submitted_at = fields.DatetimeField(auto_now_add=True)