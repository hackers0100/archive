source .venv/bin/activate
pip install -r requirements.txt
python3 -m uvicorn main:app --port 443 --reload --ssl-keyfile=./key.pem --ssl-certfile=./cert.pem --host 0.0.0.0
python3 -m uvicorn httpr:app --port 80 --host 0.0.0.0