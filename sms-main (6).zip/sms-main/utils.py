from db.models import User
from quart_auth import current_user, login_required
from quart import (
    Blueprint,
    jsonify,
    request,
    current_app,
    render_template_string,
    abort,
    redirect
)
from functools import wraps


async def render(content, **context):
    user = context.get("user", current_user)
    if user.auth_id != None:
        try:
            cadet = await User.get(id=user.auth_id).prefetch_related("model_")
        except:
            return redirect("/logout")
        
        context['cadet'] = (await cadet.model_)[0]
        context['is_admin'] = (cadet.role == "admin")
    return await render_template_string(content, **context)

def admin_only(f):
    @wraps(f)
    @login_required
    async def decor(*a, **k):
        usr = await User.get(id=current_user.auth_id)
        if usr.role != "admin":
            current_app.logger.warning(f"Forbidden request tried at '{request.path}'")
            return abort(403)
        
        return await current_app.ensure_async(f)(*a, **k)

    return decor