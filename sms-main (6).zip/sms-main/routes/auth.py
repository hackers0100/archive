from quart import (
    Blueprint,
    redirect,
    request,
    render_template_string,
)

from templates import (
    login as login_temp
)
from utils import render
from db.models import Cadet, User
from quart_auth import QuartAuth, AuthUser, login_user, logout_user, current_user

app = Blueprint('auth', __name__, url_prefix="/")

@app.route('/login', methods=['GET', 'POST'])
async def login():
    if current_user.auth_id:
        return redirect("/")
    if request.method=="GET":
        return await render(login_temp.page, user=current_user)
    
    form = await request.form
    u = await Cadet.get_or_none(sch_no=int(form['schno'])).prefetch_related("user")
    if u:
        usr = await u.user
        if usr.password == form['pwd']:
            login_user(usr)
            return redirect("/")
    
        return await render(login_temp.page, user=current_user, error=repr("Invalid Credentials"))
    
    u=await User.create(username=form["schno"], password=form["pwd"])
    await Cadet.create(sch_no=int(form["schno"]), user = u)
    login_user(u)
    return redirect("/")

@app.route("/logout")
async def logout():
    logout_user()
    return redirect("/")