from quart import Blueprint, make_response, request, redirect
from . import cadets


api = Blueprint("api", __name__, url_prefix="/api")

api.register_blueprint(cadets.app, url_prefix="/cadets")

@api.route("/theme")
async def theme_api():
    res = await make_response(redirect(request.referrer or "/"))
    res.set_cookie('theme', "light" if request.cookies.get("theme", "dark") == "dark" else "dark")
    return res
