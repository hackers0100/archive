import json
from quart import (
    Blueprint,
    jsonify,
    request
)
from db.models import Cadet, User
from utils import admin_only


app = Blueprint('/api/cadets', __name__)

@app.route('/list')
async def list_cdt():
    cdts = [await i.json() for i in await Cadet.all()]
    return jsonify(cdts)

@app.route("/<int:reg_id>", methods=["DELETE", "PATCH"])
@admin_only
async def delete_cdt(reg_id):
    registration = await Cadet.get(sch_no=reg_id)
    usr: User = await registration.user
    if request.method=="DELETE": await usr.delete()
    else:
        d = json.loads((await request.data).decode())
        usr.password = d["pwd"]
        await usr.save()
    return "", 200