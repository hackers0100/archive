from quart import (
    Blueprint,
    jsonify,
    request,
    render_template_string
)
from db.models import Cadet, Question, User
from quart_auth import login_required, current_user
from templates.quiz import quiz, index, result
from utils import render

app = Blueprint('quiz', __name__, url_prefix="/quiz")

@app.route('/')
@login_required
async def quiz_home():
    return await render(index.page, user=current_user, title="Quizzes | SSAP")

async def submit_quiz():
    data = await request.form
    score = 0
    total = 0
    questions = {}
    for key in data:
        if key.startswith("q") and not key.endswith("_id"):
            total += 1 if data[key] != "0" else 0
            qn = key[1:]
            qid = data[f"q{qn}_id"]
            selected_answer = data[key]
            question = await Question.get(id=int(qid))
            questions[qn] = [question, selected_answer]
            if question and str(question.correct_option) == selected_answer:
                score += 1

    cadet = await User.get(id=current_user.auth_id).prefetch_related("model_")
    cadet: Cadet = (await cadet.model_)[0]
    if cadet:
        cadet.score = score * 100 / 20
        cadet.total = 20 * 100 / 20
        await cadet.save()

    return await render(result.page, user=current_user, score=score, total=total, questions=questions)

@app.route('/gk', methods=['GET', 'POST'])
@login_required
async def gk_quiz():
    if request.method == 'GET':
        questions = await Question.get_random_questions(20, category="GK")
        return await render(quiz.page, user=current_user, questions=questions, title="GK Quiz | SSAP")
    
    return await submit_quiz()

