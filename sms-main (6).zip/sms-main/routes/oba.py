from quart import (
    Blueprint,
    request as req,
    render_template,
)
from utils import admin_only
from db.models import OBARegistration
from quart_auth import current_user
from datetime import datetime


app = Blueprint('oba', __name__, url_prefix="/oba")

@app.route("/", methods=["GET", "POST"])
async def oba():
    if req.method == "GET":
        return await render_template("oba/index.html")
    
    form = await req.form
    name = form.get("name")
    sch_no = int(form.get("schno"))
    year = form.get("yop")
    occupation = form.get("occupation")
    email = form.get("email")
    phone = int(form.get("phone-number"))
    address = form.get("address")
    food_pref = form.get("food_choice")
    doa = form.get("doa")
    doa = datetime.strptime(doa, "%Y-%m-%dT%H:%M")

    msg = form.get("message")
    print(f"Received OBA form submission: {name}, {sch_no}, {year}, {occupation}, {email}, {phone}, {address}, {food_pref}, {doa}, {msg}")
    await OBARegistration.create(
        name=name,
        sch_no=sch_no,
        year_of_passing=year,
        occupation=occupation,
        email=email,
        phone=phone,
        address=address,
        food_preference=food_pref,
        date_of_arrival=doa,
        message=msg
    )
    return await render_template("oba/index.html", name=name, success=True)


@app.route("/list")
@admin_only
async def oba_list():
    registrations = await OBARegistration.all().order_by('-submitted_at')
    return await render_template("oba/list.jinja.html", registrations=registrations, user=current_user)

@app.route("/<int:reg_id>", methods=["DELETE"])
@admin_only
async def delete_oba_registration(reg_id):
    registration = await OBARegistration.get(id=reg_id)
    await registration.delete()
    return "", 200