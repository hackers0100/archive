from quart import (
    Blueprint,
    request as req,
    render_template,
)
from utils import admin_only, render
from quart_auth import current_user
from templates import cdtlist


app = Blueprint('cadets', __name__, url_prefix="/cadets")

@app.route("/")
@admin_only
async def oba():
    return await render(cdtlist.page, user=current_user)
    