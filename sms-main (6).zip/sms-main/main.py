from quart import (
    Quart,
    redirect,
    request as req,
    make_response as mk_res,
    send_from_directory,
    render_template,
    abort
)
from quart_auth import QuartAuth, AuthUser, login_user, logout_user, current_user, login_required
from tortoise.contrib.quart import register_tortoise
from utils import render
from routes import api, auth, quiz, oba, cadets
from templates.index import page
from templates import cdtlist as cdts
from templates.errors.e401 import page as e401_page


DEBUG = __name__ == "__main__"
app = Quart(__name__, **(dict(static_url_path=None) if DEBUG else {}))
app.config['DEBUG'] = DEBUG
app.config["QUART_AUTH_SECRET_KEY"] = app.secret_key = "ghjkl"
QuartAuth(app)
app.config['SEND_FILE_MAX_AGE_DEFAULT'] = 0
app.config['SESSION_COOKIE_SECURE'] = True


register_tortoise(app, config={
    'connections': {
        'default': 'sqlite://db/tempdb'
    },
    'apps': {
        'models': {
            'models': ['db.models'],
            'default_connection': 'default',
        }
    }
}, config_file=None, db_url=None, modules=None, generate_schemas=True)

app.register_blueprint(api.api)
app.register_blueprint(auth.app)
app.register_blueprint(quiz.app)
app.register_blueprint(oba.app)
app.register_blueprint(cadets.app)

@app.route("/")
@login_required
async def index():
    return await render(page, user=current_user)

@app.route("/theme")
async def theme():
    res = await mk_res(redirect(f'/static/css/themes/{req.cookies.get("theme", "dark")}.css'))
    res.headers["Cache-Control"] = "no-store"
    res.headers["Content-Type"] = "text/css"
    return res

if DEBUG:
    @app.route("/x")
    async def x():
        from db.models import Cadet, User
        u=await User.create(username="0000", password="admin", role="admin")
        await Cadet.create(sch_no=0, user = u)
        from db.models import Question
        import csv
        rdr = csv.reader(open("static/qb/GK.csv"))
        for _, question_text, option1, option2, option3, option4, correct_option, explanation in rdr:
            await Question.create(
                question_text=question_text,
                option1=option1,
                option2=option2,
                option3=option3,
                option4=option4,
                correct_option=int(correct_option),
                explanation=explanation
            )

        return "hi"

    @app.route('/static/<path:filename>')
    async def serve_static_manual_cache(filename):
        response = await mk_res(await send_from_directory('static', filename))
        response.headers['Cache-Control'] = 'no-cache, no-store, must-revalidate'
        return response


@app.errorhandler(401)
async def unauthorized(e):
    if req.path=="/":
        return await render(e401_page, user=current_user), 200
    
    return redirect("/")

@app.errorhandler(403)
async def forbidden(e):  
    return redirect("/")

if DEBUG:
    app.run("0.0.0.0", port=8090, debug=DEBUG, ssl_context=("cert.pem", "key.pem"))