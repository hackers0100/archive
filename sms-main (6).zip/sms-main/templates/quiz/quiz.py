from syqlorix.templating import *
from syqlorix.templating import _
from ..includes import head, nav

page = html()
page / head.page / body(
    nav.page,
    _("div#content")(
        style("ul {list-style-type: none;} input {float: right} .input.checked {border-color: var(--primary);} .question-card.hidden, .button.hidden {display: none;}"),
        style(".button.disabled {pointer-events: none; opacity: 0.6; border-color: var(--text-secondary);}"),
        div.center(
            _("h4#timer")("Time Remaining: 00:00"),
            hr,
        ),
        _("form", method="POST")(
            "{% for q in questions %}",
                "{% set lox = loop.index %}",
                _("div.question-card.input-holder.{{'hidden' if lox!=1 else 'shown'}}#qw{{lox}}")(
                    _("p.question-text")("{{lox}}. {{q.question_text}}"),
                    input(type="hidden", name="q{{lox}}_id", value="{{q.id}}"),
                    _("ul.options")(
                        input(type="radio", name="q{{lox}}", value="0", style="display: none;", checked=True),
                        _(".input-holder")(_("li.input.q{{lox}}#q{{lox}}1")("A. {{q.option1}}", input(type="radio", name="q{{lox}}", value="1"))), br,
                        _(".input-holder")(_("li.input.q{{lox}}#q{{lox}}2")("B. {{q.option2}}", input(type="radio", name="q{{lox}}", value="2"))), br,
                        _(".input-holder")(_("li.input.q{{lox}}#q{{lox}}3")("C. {{q.option3}}", input(type="radio", name="q{{lox}}", value="3"))), br,
                        _(".input-holder")(_("li.input.q{{lox}}#q{{lox}}4")("D. {{q.option4}}", input(type="radio", name="q{{lox}}", value="4"))), br,
                    ),
                ),
            "{% endfor %}",
            _("div.input-holder")(
                _("a.button.disabled.submit-btn#prev-btn")("Previous", style="float: left"),
                _("a.button.submit-btn#next-btn")("Next", style="float: right"),
                _("a.button.hidden.submit-btn#submit-btn")("Submit", style="float: right", onclick="submitQuiz()"),
            ),
            br,
            br,
            style("""
/* make .button stack on narrow viewports; override inline floats */
@media (max-width: 700px) {
  .input-holder a.button,
  .input-holder .submit-btn {
    float: none !important;
    width: calc(100% - 24px) !important;
    margin: 6px auto !important;
    box-sizing: border-box;
  }
  /* allow jump buttons to wrap to next line */
  #jw { 
    display: flex; 
    flex-wrap: wrap; 
    overflow-x: visible; 
  }
  .jump-btn {
    margin: 2px; 
  }
}
.jump-btn {
    display: inline-block;
    padding: 10px 15px;
    border: 2px solid var(--text-secondary);
    border-radius: 5px;
    text-decoration: none;
    font-size: 12px;
    text-align: center;
    cursor: pointer;
    margin: 5px;
}
.jump-btn:hover {
    border-color: var(--primary);
}
.jump-btn.answered {
    border-color: var(--primary);
    color: var(--primary);
}
.jump-btn:active, .jump-btn.selected {
    border-color: var(--secondary);
    color: var(--secondary);
}
#jw {
    display: flex;
    overflow-x: auto;
    white-space: nowrap;
    justify-content: center;
}
"""),
            _("div.input-holder.center#jw")(
                "{% for q in questions %}",
                    "{% set lox = loop.index %}",
                    _("a.jump-btn#jumpq{{lox}}",
                        style=""
                    )(
                        "{{lox}}", onclick="jumpToQuestion({{lox}})"
                    ),
                "{% endfor %}",
            ),
        ),
        script("""
let timerDuration = 5 * 60;
let timerElement = document.getElementById("timer");
let timerInterval = setInterval(async () => {
    let minutes = Math.floor(timerDuration / 60);
    let seconds = timerDuration % 60;
    timerElement.textContent = `Time Remaining: ${minutes}:${seconds < 10 ? '0' : ''}${seconds}`;
    if (timerDuration <= 0) {
        clearInterval(timerInterval);
        await Swal.fire({
            title: 'Time is up!',
            text: 'The quiz will be submitted automatically.',
            icon: 'warning',
            confirmButtonText: 'OK'
        });
        document.querySelector("form").submit();
    }
    timerDuration--;
}, 1000);

function submitQuiz() {
    Swal.fire({
        title: 'Submit Quiz?',
        text: "Are you sure you want to submit the quiz?",
        icon: 'question',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Submit'
    }).then((result) => {
        if (result.isConfirmed) {
            let form = document.querySelector("form");
            form.submit();
        }
    });
    /* if (confirm("Are you sure you want to submit the quiz?")) {
        let form = document.querySelector("form");
        form.submit();
    } */
}
let totalQuestions = {{questions|length}};
let currentQuestion = 1;
$("#next-btn").on("click", () => {
    if (currentQuestion < totalQuestions) {
        jumpToQuestion(currentQuestion+1);
    }
});

$("#prev-btn").on("click", () => {
    if (currentQuestion > 1) {
        jumpToQuestion(currentQuestion-1);
    }
});

function jumpToQuestion(qNum) {
    if (qNum >= 1 && qNum <= totalQuestions) {
        $(`#qw${currentQuestion}`).addClass("hidden");
        currentQuestion = qNum;
        $(`#qw${currentQuestion}`).removeClass("hidden");
        if (currentQuestion == 1) {
            $("#prev-btn").addClass("disabled");
        } else {
            $("#prev-btn").removeClass("disabled");
        }
        if (currentQuestion == totalQuestions) {
            $("#next-btn").addClass("hidden");
            $("#submit-btn").removeClass("hidden");
        } else {
            $("#next-btn").removeClass("hidden");
            $("#submit-btn").addClass("hidden");
        }
        $(`#jumpq${currentQuestion}`).addClass("selected");
        $(".jump-btn").not(`#jumpq${currentQuestion}`).removeClass("selected");
    }
}
               
$("li.input").on("click", (e) => {
    let tgt = e.target;
    while (!tgt.classList.contains("input")) {
        tgt = tgt.parentElement;
    }
    inp = tgt.querySelector("input");
    inp.checked=true;
    $(`.${inp.name}`).removeClass("checked");
    $(`#${inp.name}${inp.value}`).addClass("checked")
    $(`#jumpq${currentQuestion}`).addClass("answered");
});"""),
    ),
)
page = page.render()