# template (page) to show result of quiz  (each question with correct answer highlighted)
from syqlorix.templating import *
from syqlorix.templating import _
from ..includes import head, nav

page = html()
page / head.page / body(
    nav.page,
    _("div#content")(
        style("ul {list-style-type: none;} input {float: right} .input.checked {border-color: var(--primary);} .hidden {display: none;}"),
        style(".input.correct {border-color: var(--primary); color: var(--primary)} .input.wrong {border-color: #dc3545; color: #dc3545;}"),
        h1("Quiz Result"),
        _("div#score")(
            h2.input.center("Total: {{questions|length}}"),
            h2.input.center("Correct: {{ score }}"),
            h2.input.center("Incorrect: {{ total - score }}"),
            h2.input.center("Not Attempted: {{ questions|length - total }}"),
        ),
        _("div.question-card.hidden#questions")(
            "{% for qno, items in questions.items() %}",
                "{% set question = items[0] %}",
                "{% set ua = items[1] %}",
                _("div.question-card.input-holder")(
                    h3("{{qno}}. {{ question.question_text }}"),
                    "{% set correct_option = question.correct_option %}",
                    "{% if ua == '0' %}",
                        "Not Attempted.",
                    "{% elif ua|int == correct_option %}",
                        "Correct Answer Selected.",
                    "{% else %}",
                        "Wrong Answer Selected.",
                    "{% endif %}",
                    _("ul.options")(
                        _(".input-holder")(_("li.input.{{'correct' if correct_option == 1 else ('wrong' if 1 == ua|int else '')}}")(span("{{ question.option1 }}"))), br,
                        _(".input-holder")(_("li.input.{{'correct' if correct_option == 2 else ('wrong' if 2 == ua|int else '')}}")(span("{{ question.option2 }}"))), br,
                        _(".input-holder")(_("li.input.{{'correct' if correct_option == 3 else ('wrong' if 3 == ua|int else '')}}")(span("{{ question.option3 }}"))), br,
                        _(".input-holder")(_("li.input.{{'correct' if correct_option == 4 else ('wrong' if 4 == ua|int else '')}}")(span("{{ question.option4 }}"))), br,
                    ),
                ),
            "{% endfor %}"
        ),
        a.button("SHOW ANSWERS", id="showAnswers", style="margin-top: 20px; display: block; text-align: center;", onclick="""document.getElementById('questions').classList.remove('hidden');document.getElementById('showAnswers').style.display='none';"""),
        a.button("DONE", href="/quiz/", style="margin-top: 20px; display: block; text-align: center;"),
    ),
    script("""

$(document).ready(async function() {
    await Swal.fire({
        title: 'Quiz Submitted!',
        text: 'Your score is {{ score }} out of {{ questions|length }}.',
        icon: 'success',
        confirmButtonText: 'OK'
    });
});
           """)
)

page = page.render()