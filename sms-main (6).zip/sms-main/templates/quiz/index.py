from syqlorix.templating import *
from syqlorix.templating import _
from ..includes import head, nav

page = html()
page / head.page / body(
    nav.page,
    _("div#content")(
        h1("Quizzes"),
        "{% if cadet.total != 0 %}",
            h2.input.center("Your Score: {{ cadet.score }} / {{ cadet.total }}"),
        "{% else %}",
            h2.input.center("You have not taken any quizzes yet."),
        "{% endif %}",
        a.button("GK Quiz", href="/quiz/gk")
    ),
)
page = page.render()