from syqlorix.templating import *
from syqlorix.templating import _
from .includes import head, nav

page = html()
page / head.page / body(
    nav.page,
    script(src="static/js/form.js"),
    _("#content")(
        _("form.center", method="POST", onsubmit="return validateForm(event)")(
            _(".input-holder")(
                input.input(type='text', placeholder=' ', name="name", id="name", **{"data-required": True}, autofocus=True),
                div.placeholder("Full Name")
            ),
            br,
            _(".input-holder")(
                input.input(type="number", placeholder=" ", name="schno", id="schno", **{"data-required": True}),
                div.placeholder("School Number")
            ),
            br,
            _(".input-holder")(
                _("textarea.input#longdesc", rows=7, name="msg", required=True)(""),
                _(".textarea-placeholder")("Message")
            ),
            br,
            _(".input-holder")(
                input(type="submit", style="display:none"),
                _("a.submit-btn.button")("Submit", onclick="submit(event)"),
                _("a.submit-btn.button")("Clear", onclick="document.querySelector(\"form\").reset()")
            )
        )
    )
)
page = page.render(pretty=False)