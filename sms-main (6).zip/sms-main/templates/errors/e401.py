from syqlorix.templating import *
from syqlorix.templating import _
from ..includes import head, nav, foot

page = html()
page / head.page / body(
    nav.page,
    _("#content")(
        a.button("Cadet Login", href="/login"),
        a.button("OBA Registration", href="/oba"),
    )
) / foot.page
page = page.render()