from syqlorix.templating import *


page = head(
    meta(property='og:title', content="{{title if title else 'Sainik School Ambikapur'}}"),
    meta(property='og:type', content='website'),
    meta(name='og:image', content='/static/img/logo.png'),
    meta(name='theme-color', content='#d2efe6'),
    meta(content='width=device-width, initial-scale=1.0', name='viewport'),
    link(rel='shortcut icon', type='image/png', href='/static/img/logo.png'),
    link(href='/static/css/main.css', rel='stylesheet'),
    link(href='/theme', rel='stylesheet'),

    # Font from google fonts,
    link(href='https://fonts.googleapis.com/icon?family=Markazi+Text', rel='stylesheet'),
    # CKEDITOR 4 for Description editing in HTML,
    script(src='https://cdn.ckeditor.com/4.14.1/standard/ckeditor.js'),

    # jQuery,
    script(src='https://ajax.aspnetcdn.com/ajax/jQuery/jquery-3.3.1.min.js'),

    # Noty,
    script(src='https://cdnjs.cloudflare.com/ajax/libs/noty/3.1.4/noty.min.js'),
    link(href='https://cdnjs.cloudflare.com/ajax/libs/noty/3.1.4/noty.css', rel='stylesheet'),

    # FontAwesome,
    link(href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.14.0/css/all.min.css', rel='stylesheet'),

    script(src='/static/js/main.js'),
    script(src='/static/js/cards.js'),

    # Import SWAL,
    script(src='https://cdn.jsdelivr.net/npm/sweetalert2@9'),

    title("{% block title %}{{title if title else 'Sainik School Ambikapur'}}{% endblock %}")
)
