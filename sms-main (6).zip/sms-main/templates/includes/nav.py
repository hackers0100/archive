from syqlorix.templating import *
from syqlorix.templating import _
from . import arrow


page = _("div#navTop")(
    span.nav.link(
        a(
            img(src='/static/img/logo.png'),
            href="/"
        )
    ),
    span.navtag(
        a(href="/") / span.navtext.keep("Sainik School Ambikapur"),
        arrow.page
    )
) / span.dropdown(
    "{% if user.auth_id != None %}",
        a.navtag.keep(
            "{{'Admin' if is_admin else 'School Number: '+cadet.sch_no|string}}",
            id="login",
            href='/login'
        ),
        span(
            # a("Toggle Theme", href='/api/theme'),
            # br(),
            a("Logout", href='/logout'),
            class_="dd-content"
        ),
    "{% else %}",
        a.navtag.keep(
            "Login",
            id="login",
            href='/login'
        ),
    "{% endif %}"
)
