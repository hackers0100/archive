from syqlorix import Node
from syqlorix.templating import NodeWrapper

svg = NodeWrapper(type("svg", (Node,), {})) # pyright: ignore[reportArgumentType]
g = NodeWrapper(type("g", (Node,), {})) # pyright: ignore[reportArgumentType]
path = NodeWrapper(type("path", (Node,), {})) # pyright: ignore[reportArgumentType]

page = svg.arrow(
    g(
        g(
            g(
                g(
                    path(
                        id="Combined-Shape-Copy",
                        d='M1.8537 34.7643l15.5597-17.268L1.8537 0H0l15.5597 17.4964L0 34.7644z'
                    ),
                    id="Group-2"
                ),
                id="Group-13"
            ),
            id='community/header',
            fill='#3369E6'
        ),
        id="Symbols",
        fill='none',
        **{"fill-rule": 'evenodd'}
    ),
    viewbox='0 0 18 35',
    xmlns='http://www.w3.org/2000/svg'
).render()