from syqlorix.templating import br, div, style, p, a

page = div() / div.footer(
        p(
            a("Designed by - Sch. No. 1183 Cdt Pratik Mahanta, 11th A (CS)", href="https://arceuspratik.github.io/", target="_blank"), br,
            a("Developed by - Sch. No. 1193 Cdt Rishi Raj Ranjan, 11th A (CS)", href="https://rishiraj0100.github.io", target="_blank"),
        ),
    ) / style("""
.footer {
    left: 0;
    bottom: 0;
    width: 100%;
    color: var(--text-secondary);
    text-align: center;
    padding: 10px 0;
    position: fixed;
}
body, html {
    height: 100vh;
    margin: 0;
}""")
