from syqlorix.templating import *
from .includes import head, nav

page = html()
page / head.page / body(
    nav.page,
    div(
        div(
            "| Would you like to",
            a(href='/cadets/search/'),
            "search all cadets",
            id="searchMore"
        ),
        div(
            span(
                "Loading...",
                id="loading"
            ),
            id="cards"
        ),
        id="content"
    ),
    onload="load()"
)
page = page.render()