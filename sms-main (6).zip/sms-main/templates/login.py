from syqlorix.templating import *
from syqlorix.templating import _
from .includes import head, nav

page = html()
page / head.page / body(
    nav.page,
    span.scripts(
        script(src="static/js/form.js"),
        "{% if error %}",
            script("""
$(document).ready(async function() {
    await Swal.fire({
        title: 'Login Failed',
        text: {{ error|safe }},
        icon: 'error',
        confirmButtonText: 'OK'
    });
});
"""),
        "{% endif %}",
    ),
    _("#content")(
        _("form.center", method="POST", onsubmit="return validateForm(event)")(
            _(".input-holder")(
                input.input(type='number', placeholder=' ', name="schno", id="schno", **{"data-required": True}, autofocus=True),
                div.placeholder("School Number")
            ),
            br,
            _(".input-holder")(
                input.input(type="password", placeholder=" ", name="pwd", id="pwd", **{"data-required": True}),
                div.placeholder("Password")
            ),
            br,
            _(".input-holder")(
                input(type="submit", style="display:none"),
                _("a.submit-btn.button")("Clear", onclick="document.querySelector(\"form\").reset()", style="float: left"),
                _("a.submit-btn.button")("Submit", onclick="submit(event)", style="float: right"),
            )
        )
    )
)
page = page.render()